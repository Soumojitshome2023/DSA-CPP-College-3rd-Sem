#include<iostream>
#include<string.h>
#include<ctype.h>
#include<math.h>

struct Node{
	int data;
	struct Node *next;
}






//================= Main Function =================
int main(){
	int num;
	struct Node *head;
	head = (struct Node*)malloc(sizeof(struct Node));
	return 0;
}

//===================================================

