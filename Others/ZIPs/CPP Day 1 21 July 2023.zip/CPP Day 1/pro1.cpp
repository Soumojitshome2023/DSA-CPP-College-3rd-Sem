#include<iostream>
using namespace std;

// First Code

int main(){

	cout<<"Hello World";


	return 0;
}
